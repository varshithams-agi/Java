-------------------------------1/12----------------------------------------

public class demo {
	public static void main(String a[]) {
		
		final double PI = 3.14;
		Object math;
		float principle=200, rate=6, time=3,avg;
		int f=10,b=20,c=4,d=25,e=30,sum,width=5,height=10,areaOfRectangle,areaOfCircle,areaOfSquare,s=5;
		float simpleInterest1= (principle*rate*time)/100;
		System.out.println("Simple interest is"+simpleInterest1);
		sum=f+b+c+d+e;
		avg=sum/5;
		System.out.println("Average of two numbers"+avg);
		areaOfRectangle=width*height;
		System.out.println("Area of rectangle"+areaOfRectangle);
		int raduis = 6;
		double areaOfCircle1= PI*raduis*raduis;
		System.out.println("Area of circle"+areaOfCircle1);
		areaOfSquare=s*s;
		System.out.println("Area of square"+areaOfSquare); 
		
		
// even or odd	
		int a=20;
		int b=50;
		int c= 6;
		
		System.out.println("1)To check even or odd");
		if(a%2==0) {
			System.out.println(" number is even");
		}	
		else {
			System.out.println(" number is odd");
		}
// +ve or -ve	
		System.out.println("2)to check +ve or -ve");
		if(b>=0) {
			System.out.println(" number is possitive");
		}
		else {
			System.out.println(" number is negative");
		}
//greatest of 3	
		System.out.println("3)greatest of 3");
		if(a>b && a>c) {
			System.out.println(" a is greater");
		}
		else if(b>c) {
			System.out.println(" b is greater");
		}
		else {
			System.out.println(" c is greater");
		}
//student grade		
		System.out.println("4)grade of a students");
		float marks=30;
		if(marks>90 && marks<=100) {
			System.out.println(" grade is a");
		}
		else if(marks>80 && marks<=90) {
			System.out.println(" grade is b");
		}
		else{
			System.out.println(" grade is c");
		}
//greatest of 4		
		System.out.println("5) greatest of 4");
		int number1=100;
		int number2=45;
		int number3=23;
		int number4=15;
		if(number1 > number2)
	      {
	         if(number1 > number3)
	         {
	            if(number1 > number4)
	            {  
	               System.out.println("Largest of four numbers is: " + number1);
	            }
	            else
	            {
	               System.out.println("Largest of four numbers is: " + number4);
	            }
	         }
	      }
	      else if(number2 > number3)
	      {
	         if(number2 > number4)
	         {
	            System.out.println("Largest of four numbers is: " + number2);
	         }
	         else
	         {
	            System.out.println("Largest of four numbers is: " + number4);
	         }
	      }
	      else if(number3 > number4)
	      {
	         System.out.println("Largest of four numbers is: " + number3);
	      }
	      else
	      {
	         System.out.println("Largest of four numbers is: " + number4);
	      }
		  
		  
//phone bill		
		System.out.println("6) generate bill of calls");
		 int calls=290; // 190= 100+180
		    if(calls<=100)
		    {
		        System.out.println("Bill : Rs.0");
		    }
		    else if(calls>100 && calls<=200)
		    {
		        calls=calls-100;
		        System.out.println(calls);
		    }
		    else if(calls>200 && calls<=300)
		    {
		        calls=(calls-200)*2+100;
		        System.out.println(calls);
		    }
		    else {
		        calls=(calls-300)*3+300;
		        System.out.print(calls);
		    }
			
			
			
//electricity bill

		int units=290;
	    if(units<=50)
	    {
	        System.out.println("Bill : Rs.0");
	    }
	    else if(units>50 && units<=100)
	    {
	        units=(units-50)*6;
	        System.out.println(units);
	    }
	    else if(units>100 && units<=150)
	    {
	        units=(units-100)*8+(50*6);
	        System.out.println(units);
	    }
	    else {
	        units=(units-150)*9+(50*6)+(50*8);
	        System.out.print(units);
	    }
			

		
//factorial of number		
		int n=4;
		int fact=1;
		for(int i=1; i<=n;i++) {
			fact=fact*i;
		}
		System.out.println("factorial of "+n+" is "+fact);
		
//sum of 1st 100 even numbers
	int sum=0, num = 1;
		
		for(int count=1; count<=100; ){
		    
		    if(num%2 == 0){
		        sum += num;
		        count++;
		    }
		    num++;
		}
		
		System.out.println("Sum of 1st 100 even numbers: "+sum);

// sum of 50 odd numbers
int sum3=0, num2 = 1;
		
		for(int count=1; count<=50; ){
		    
		    if(num2%2 != 0){
		        sum3 += num2;
		        count++;
		    }
		    num2++;
		}
		
		System.out.println("Sum of 1st 100 even numbers: "+sum3);
		

//sum of numbers /by 3 and 9 between 1 to 1000
		int sum2=0;
		for(int i=1;i<1000;i++) {
			if(i%3==0 && i%9==0) {
				sum2=sum2+i;
			}
			
		}
		System.out.println("sum of numbers /by 3 and 9 between 1 to 1000 is "+sum2);	


// to find number is prime or not
		int n=4;
		int m=n/2;
		int flag=0;
		for(int i=2;i<=m;i++){      
			if(n%i==0){      
				System.out.println(n+" is not prime number");      
				flag=1;      
				break;      
			}      
		}      
		if(flag==0){ 
			System.out.println(n+" is prime number"); 
		}
		
//Fibonacci series of 20 numbers		
	int fib=0;
	int num1=0;
	int num2=1;
	System.out.println("fibonacci series of 20 numbers:\n"+num1+"\n"+num2);
	for(int count=2;count<20; count++) {
		fib=num1+num2;
		System.out.println(fib);
		num1=num2;
		num2=fib;
	}		

		
//pattern

				
	for(int row=1;row<=5;row++) {
		for(int col=1;col<=row;col++) {
			System.out.print("*");
		}
		System.out.println();
	}
		
		
		
		
	}

}
-----------------------------------------------------------------------------------------------
-------------------------------2/12-------------------------------------------------------------

package demo;

public class project {

	public static void main(String[] args) {
//table of 2 using while		
		int n=2;
		int i=1;
		int r;
		while(i<=10) {
			r=n*i;
			System.out.println(n+" * "+i+" = "+r);
			i++;
		}
		System.out.println("\n");
//table of 2 using do while
		int n1=2;
		int i1=1;
		int r1;
		do {
			r1=n1*i1;
			System.out.println(n1+" * "+i1+" = "+r1);
			i1++;
		}while(i1<=10);
		System.out.println("\n");
		
//factorial using while
		int n3=4;
		int fact=1;
		int i3=1;
		while(i3<=n3) {
			fact=fact*i3;
			i3++;
		}
		System.out.println("factorial of "+n3+" is "+fact);
		
		System.out.println("\n");
		
//factorial using  do while
				int n4=4;
				int fact2=1;
				int i4=1;
				do {
					fact2=fact2*i4;
					i4++;
				}
				while(i4<=n4);
				System.out.println("factorial of "+n4+" is "+fact2);
				System.out.println("\n");
				
// fibonacci series of 20 numbers using while loop				
				int fib=0;
				int num1=0;
				int num2=1;
				int count=2;
				System.out.println("fibonacci series of 20 numbers:\n"+num1+"\n"+num2);
				while(count<20 ) {
					fib=num1+num2;
					System.out.println(fib);
					num1=num2;
					num2=fib;
					count++;
				}
				
				System.out.println("\n");
				
// fibonacci series of 20 numbers using while loop	
				int fib1=0;
				int numb1=0;
				int numb2=1;
				int count1=2;
				System.out.println("fibonacci series of 20 numbers:\n"+numb1+"\n"+numb2);
				do {
					fib1=numb1+numb2;
					System.out.println(fib1);
					numb1=numb2;
					numb2=fib1;
					count1++;
				}while(count1<20);	

	}

}
// calculator using scanner class
package demo;
import java.util.Scanner;

public class project {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		char ch='y';
		do{
			System.out.println("calculator............");
			System.out.println("enter 1st number");
			int num1= sc.nextInt();
			System.out.println("enter 2st number");
			int num2= sc.nextInt();
			System.out.println("select your option");
			System.out.println("1.Addition");
			System.out.println("2.subtraction");
			System.out.println("3. Multiplication");
			System.out.println("4. Division");
			int num3= sc.nextInt();
			int result;
			if(num3==1) {
				result = num1+num2;
				System.out.println("addition of "+num1+ " & "+num2+" is "+result);
			}
			else if(num3==2) {
				result = num1-num2;
				System.out.println("subtraction of "+num1+ " & "+num2+" is "+result);
			}
			else if(num3==3) {
				result = num1*num2;
				System.out.println("Multiplication of "+num1+ " & "+num2+" is "+result);
			}
			else if(num3==4) {
				result = num1/num2;
				System.out.println("division of "+num1+ " & "+num2+" is "+result);
			}
			else {
				System.out.println("enter correct option");
			}
			
			System.out.println("do yo want to repeat(y/n)");
			ch = sc.next().charAt(0);
			
		}while(ch=='y');

		if(ch=='n') {
			System.out.println("Thank you");
		}
		 sc.close();
	}

}

//food order bill

package demo;
import java.util.Scanner;

public class project {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int sum=0;
		char ch;
		do {
			System.out.println("bill order: \n 1.breakfast\n 2.lunch\n 3.dinner");
			int choice=sc.nextInt();
			if(choice==1) {
				System.out.println("breakfast: \n 1.idli\n 2.dosa\n 3.poori");
				int choice1=sc.nextInt();
				if(choice1==1) {
					sum+=30;
					System.out.println("idli of rs 30");
				}
				else if(choice1==2) {
					sum+=40;
					System.out.println("dosa of rs 40");
				}
				else if(choice1==3) {
					sum+=50;
					System.out.println("poori of rs 50");
				}
				
			}
			else if(choice==2) {
				System.out.println("lunch: \n 1.daal\n 2.naan\n 3.rooti");
				int choice2=sc.nextInt();
				if(choice2==1) {
					sum+=50;
					System.out.println("daal of rs 50");
				}
				else if(choice2==2) {
					sum+=40;
					System.out.println("naan of rs 40");
				}
				else if(choice2==3) {
					sum+=50;
					System.out.println("rooti of rs 50");
				}
				
			}
			else if(choice==3) {
				System.out.println("dinner: \n 1.pullav\n 2.pizza\n 3.puff");
				int choice3=sc.nextInt();
				if(choice3==1) {
					sum+=30;
					System.out.println("pullav of rs 30");
				}
				else if(choice3==2) {
					sum+=40;
					System.out.println("pizza of rs 40");
				}
				else if(choice3==3) {
					sum+=50;
					System.out.println("puff of rs 50");
				}
				
			}	
			System.out.println("do yo want to repeat(y/n)");
			ch = sc.next().charAt(0);
		
		}while(ch=='y');
	
		System.out.println("Thnk you \n total price "+sum);
		sc.close();

	}
	
}

///method examples without return type
package demo;
import java.util.Scanner;

public class project {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		project p=new project();
		System.out.println("enter the number to find factorial");
		int n= sc.nextInt();
		p.factorial(n);
		System.out.println("enter first number");
		float num1=sc.nextFloat();
		System.out.println("enter second number");
		float num2=sc.nextFloat();
		p.sum(num1,num2);
		System.out.println("enter radius of circle");
		float rad=sc.nextFloat();
		p.circle(rad);
		System.out.println("enter length");
		int len=sc.nextInt();
		System.out.println("enter width");
		int wid=sc.nextInt();
		p.square(len);
		p.rectangle(len,wid);
		
		
	}
	void factorial(int num) {
		int fact=1;
		for(int i=1; i<=num;i++) {
			fact*=i;
		}
		System.out.println("the factorial of "+num+" is "+fact);
		
	}
	void sum(float n1, float n2) {
		float result=n1+n2;
		System.out.println("sum is "+result);
		
	}
	void circle(float radius) {
		double pi=3.14;
		double area=pi*radius*radius;
		System.out.println("area of circle is "+area);
		
	}
	int square(int length) {
		
		int area=length*length;
		System.out.println("area of square is "+area);
		return 1;
	}
void rectangle(int length, int width) {
		
		int area=length*width;
		System.out.println("area of rectangle is "+area);
		
	}	
}

/////methods with return type
package demo;
import java.util.Scanner;

public class project {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		project p= new project();
		System.out.println("enter the number");
		int n=sc.nextInt();
		p.evenOdd(n);
		p.positiveNegative(n);
		p.sum();
		p.area(5);
		p.area(2,3);
		p.area(4.5f);
		
		
	}
	int evenOdd(int num) {
		if(num%2==0) {
			System.out.println("the number is even");
			
		}
		else {
			System.out.println("the number is odd");
		}
		return 1;
	}
	int positiveNegative(int num) {
		if(num>0) {
			System.out.println("the number is positive");
		}
		else {
			System.out.println("the number is odd");
		}
		return 1;
	
	}
	int sum() {
		int a=0;
		for(int i=1;i<=100;i++) {
			a=a+i;
		}
		System.out.println("sum of numbers from 1 to 100 is "+a);
		return 1;
	}
	
	int area(int value) {
		double c=3.14*value*value;
		System.out.println("area ofcircle is "+c);
		return 1;
	}
	int area(int a,int b) {
		int c=a*b;
		System.out.println("area of rectangle is "+c);
		return 1;
	}
	int area(float a) {
		float c=a*a;
		System.out.println("area of square is "+c);
		return 1;
	}
}
///static and non static 
package demo;
import java.util.Scanner;

public class project {
	static int i=3;
	int a=5;
	int changeValue() {
		i++;
		a++;
		System.out.println("value of i is"+i);
		System.out.println("value of a is"+a);
		return 1;
	}
	public static void main(String[] args) {
		project p=new project();
		System.out.println("value of i is"+i);
		
		p.changeValue();
		System.out.println("value of i is"+i);
		System.out.println("value of a is"+p.a);
		project p2=new project();
		System.out.println("value is"+p2.i);
		System.out.println("value  of a is "+p2.a);
		project p3=new project();
		System.out.println("value is"+p3.i);
		System.out.println("value of a  is"+p3.a);
	}
}
-----------------------------------------------------------------------------
------------------------------------3/12------------------------------------------------
//
package demo;

public class student {
	
	String name;
	int rollNumber;
	


	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getRollNumber() {
		return rollNumber;
	}



	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}



	public static void main(String[] args) {
		student s=new student();
		s.setName("varsha");
		System.out.println(s.getName());
		s.setRollNumber(34);
		System.out.println(s.getRollNumber());

	}

}
//constructors
package demo;

public class student {
	
	 public static void main(String aa[])
	    {
	     Employee e=new Employee("12","35000");
	     System.out.print(e.Details());
	}

	}

	class Employee
	{
	    String id,salary;

	        Employee(String x,String  sal)
	        {
	            id=x;
	            salary=sal;
	        }    

	    String Details()
	    {
	        return id+" "+salary;
	    }
}
// exampe for constuctors

package demo;

public class student {
	
	 public static void main(String aa[])
	    {
		 car cr= new car("kia", 5000000);
		 cr.displayDetails();
		 Area a1=new Area();
		 Area a2=new Area(3.5f);
		 Area a3=new Area(5);
		 Area a4=new Area(2,3);
	    }  
}


    class car{
	String brandName;
	int price;
	car(String brdN, int pr ){
		this.brandName=brdN;
		this.price=pr;
	}
	void displayDetails() {
		  
		System.out.println(brandName+" "+price);
	}
}
    
    class Area{
    	float a;
    	int b;
    	Area(){
    		System.out.println("area class");
    	}
    	Area(float rad){
    		double pi=3.14;
    		this.a=rad;
    		double area=a*pi;
    		System.out.println("area of circle is "+area);
    	}
    	Area(int length){
    		this.b=length;
    		int area=b*b;
    		System.out.println("area of square is "+area);
    	}
    	Area(int length, int width){
    		this.b=length;
    		this.a=width;
    		float area=a*b;
    		System.out.println("area of rectangle is "+area);
    	}
    }

//single inheritance

package demo;
import java.util.Scanner;

public class Student {
	int studentID;
	String studentName;
	String phone;
	Scanner sc=new Scanner(System.in);
	void readDetails() {
		System.out.println("enter student id ");
		studentID=sc.nextInt();
		System.out.println("enter student name ");
		studentName=sc.next();
		System.out.println("enter student phn ");
		phone=sc.next();
	}
	void displayDetails() {
		System.out.println(" student id is: "+studentID);
		System.out.println(" student name is: "+studentName);
		System.out.println(" student phone is: "+phone);
		
	}
	public static void main(String a[]) {
		Marks m= new Marks();
		m.readDetails();
		m.readMarks();
		m.displayDetails();
		m.displayMarks();
	 
}
}
class Marks extends Student{
	int m1;
	int m2;
	int m3;
	
	void readMarks()
 {
		System.out.println("enter marks1 ");
		m1=sc.nextInt();
		System.out.println("enter marks2 ");
		m2=sc.nextInt();
		System.out.println("enter marks3 ");
		m3=sc.nextInt();
	}
	void displayMarks() {
		System.out.println(" marks1 is: "+m1);
		System.out.println("  marks2 is: "+m2);
		System.out.println("  marks3 is: "+m3);
		
	}
	
	
}

//multilevel inheritance

public class Student {
	int studentID;
	String studentName;
	String phone;
	Scanner sc=new Scanner(System.in);
	void readDetails() {
		System.out.println("enter student id ");
		studentID=sc.nextInt();
		System.out.println("enter student name ");
		studentName=sc.next();
		System.out.println("enter student phn ");
		phone=sc.next();
	}
	void displayDetails() {
		System.out.println(" student id is: "+studentID);
		System.out.println(" student name is: "+studentName);
		System.out.println(" student phone is: "+phone);
		
	}
	public static void main(String a[]) {
		Result m= new Result();
		m.readDetails();
		m.readMarks();
		m.calculateResult();
		m.displayDetails();
		m.displayMarks();
		m.displayResult();
	 
}
}
class Marks extends Student{
	int m1;
	int m2;
	int m3;
	
	void readMarks()
 {
		System.out.println("enter marks1 ");
		m1=sc.nextInt();
		System.out.println("enter marks2 ");
		m2=sc.nextInt();
		System.out.println("enter marks3 ");
		m3=sc.nextInt();
	}
	void displayMarks() {
		System.out.println(" marks1 is: "+m1);
		System.out.println("  marks2 is: "+m2);
		System.out.println("  marks3 is: "+m3);
		
	}
}

class Result extends Marks{
	int totalMarks;
	float percentage;
	String grade;
	void calculateResult() {
		totalMarks=m1+m2+m3;
		percentage=((totalMarks/300)*100);
		if(percentage>80 && percentage<=100) {
			grade="first class";
		}
		else if(percentage>60 && percentage<=80) {
			grade="second class";
		}
		else if(percentage>35 && percentage<=60) {
			grade="third class";
		}
		else if(percentage<=35){
			grade="fail";
		}
		
	}
	void displayResult() {
		System.out.println(" total marks is: "+totalMarks);
		System.out.println(" percentage is: "+percentage);
		System.out.println(" grade is: "+grade);
	}
}
//hierarchical inhritance
package demo;
import java.util.Scanner;

public class Student {
	int studentID;
	String studentName;
	String phone;
	Scanner sc=new Scanner(System.in);
	void readDetails() {
		System.out.println("enter student id ");
		studentID=sc.nextInt();
		System.out.println("enter student name ");
		studentName=sc.next();
		System.out.println("enter student phn ");
		phone=sc.next();
	}
	void displayDetails() {
		System.out.println(" student id is: "+studentID);
		System.out.println(" student name is: "+studentName);
		System.out.println(" student phone is: "+phone);
		
	}
	public static void main(String a[]) {
		System.out.println("single inheritance");
		Marks m1=new Marks();
		m1.readDetails();
		m1.readMarks();
		m1.displayDetails();
		m1.displayMarks();
		System.out.println("multilevel inheritance");
		Result m= new Result();
		m.readDetails();
		m.readMarks();
		m.calculateResult();
		m.displayDetails();
		m.displayMarks();
		m.displayResult();
		System.out.println("heirachical inheritance");
		MPCMarks a1=new MPCMarks();
		a1.readDetails();
		a1.readMPCMarks();
		a1.displayDetails();
		a1.displayMPCMarks();
		CECMarks a2=new CECMarks();
		a2.readDetails();
		a2.readCECMarks();
		a2.displayDetails();
		a2.displayCECMarks();
		
	 
}
}
class Marks extends Student{
	int m1;
	int m2;
	int m3;
	
	void readMarks()
 {
		System.out.println("enter marks1 ");
		m1=sc.nextInt();
		System.out.println("enter marks2 ");
		m2=sc.nextInt();
		System.out.println("enter marks3 ");
		m3=sc.nextInt();
	}
	void displayMarks() {
		System.out.println(" marks1 is: "+m1);
		System.out.println("  marks2 is: "+m2);
		System.out.println("  marks3 is: "+m3);
		
	}
}

class Result extends Marks{
	int totalMarks;
	int percentage;
	String grade;
	void calculateResult() {
		totalMarks=m1+m2+m3;
		percentage=(totalMarks*100)/300;
		if(percentage>80 && percentage<=100) {
			grade="first class";
		}
		else if(percentage>60 && percentage<=80) {
			grade="second class";
		}
		else if(percentage>35 && percentage<=60) {
			grade="third class";
		}
		else if(percentage<=35){
			grade="fail";
		}
		
	}
	void displayResult() {
		System.out.println(" total marks is: "+totalMarks);
		System.out.println(" percentage is: "+percentage);
		System.out.println(" grade is: "+grade);
	}
}

class MPCMarks extends Student{
	int mathMarks;
	int physicsMarks;
	int chemistryMarks;
	void readMPCMarks() {
		System.out.println("enter  mathMarks ");
		mathMarks=sc.nextInt();
		System.out.println("enter physicsMarks ");
		physicsMarks=sc.nextInt();
		System.out.println("enter chemistryMarks ");
		chemistryMarks=sc.nextInt();
		
	}
	void displayMPCMarks() {
		System.out.println(" mathMarks is: "+mathMarks);
		System.out.println("  physicsMarks is: "+physicsMarks);
		System.out.println("  chemistryMarks is: "+chemistryMarks);
	}
}

class CECMarks extends Student{
	int commerceMarks;
	int economicsMarks;
	int CmcsMarks;
	void readCECMarks() {
		System.out.println("enter  commerceMarks ");
		commerceMarks=sc.nextInt();
		System.out.println("enter economicsMarks ");
		economicsMarks=sc.nextInt();
		System.out.println("enter CmcsMarks ");
		CmcsMarks=sc.nextInt();
		
	}
	void displayCECMarks() {
		System.out.println(" commerceMarks is: "+commerceMarks);
		System.out.println("  economicsMarks is: "+economicsMarks);
		System.out.println("  CmcsMarks is: "+CmcsMarks);
	}
}

package demo;
import java.util.*;

public class Transaction {
	int accountNumber;
	double balance=30000;
	Scanner sc=new Scanner(System.in);
	int getAccountNumber() {
		System.out.println("enter account number");
		accountNumber=sc.nextInt();
		return accountNumber;
	}
	void execute() {
		
		System.out.println("account balance is"+balance);
	}
	public static void main(String a[]) {
		Transaction t=new Transaction();
		System.out.println("account number is :"+t.getAccountNumber());
		t.execute();
		BalanceInquiry bq=new BalanceInquiry();
		bq.execute();
		Withdrawal wd=new Withdrawal();
		wd.execute();
		Deposit dp = new Deposit();
		dp.execute();
		
		
	}
}

class BalanceInquiry extends Transaction{
	void execute() {
		
		System.out.println("account balance is"+balance);
	}
}
class Deposit extends Transaction{
	public double amount;
	void execute() {
		System.out.println("enter the amount todeposit");
		amount=sc.nextDouble();
		balance=balance+amount;
		System.out.println("account balance is"+balance);
	}
}

class Withdrawal extends Transaction{
	double amount;
	void execute() {
		System.out.println("enter the amount to withdraw");
		amount=sc.nextDouble();
		balance=balance-amount;
		System.out.println("account balance is"+balance);
	}
}

------------------------------------------------------------------------------------
-----------------------------------------6/12----------------------------------------
//interface

package demo;

interface IVehicle {
    
    public double tuneUpCost();
  

    public boolean canCarry(int numPassengers);
  }


public class MyClass implements IVehicle {
	
	public double tuneUpCost() {
		System.out.println("cost increased");
		return 1;
	}
	public boolean canCarry(int numPassengers) {
		System.out.println("can carry "+numPassengers+ " passengers");
		return true;
	}
	
	public static void main(String a[]) {
		MyClass mc= new MyClass();
		mc.tuneUpCost();
		mc.canCarry(500);
	}

}
//abstract class
package demo;

abstract class Animal {
	  abstract void makeSound();

	  public void eat() {
		  System.out.println("Animals will eat");

	  }
	}

public class Dog extends Animal{
	void makeSound() {
		System.out.println("dog will barks");
	}
	public static void main(String a[]) {
		Dog d=new Dog();
		d.eat();
		d.makeSound();
	}
}


package demo;
import java.util.*;

public class Task {
	public static void main(String arg[]) {
		Scanner sc=new Scanner(System.in);
//reverse of a String
		String str="hello";
		String rstr="";
		char ch;
		System.out.print("the reverse of the string is: ");
		for (int i=0; i<str.length(); i++)
	      {
	        ch= str.charAt(i); 
	        rstr= ch+rstr;  
	      }
	      System.out.println(rstr);
	    
//pattern program
	      System.out.println("Pattern program");
	      int number = 4;
	      
	      for(int i = number; i >= 1; i--)
	      {
	    	  for(int j = i; j < number; j++)
	    	  {
	    		  System.out.print(" ");
	    	  }
	    	  for(int j = 1; j <= (2 * i - 1); j++)
	    	  {
	    		  System.out.print("*");
	    	  } System.out.println("");
	      }
//calculate the power of a number
	      System.out.println("calculate the power of a number");
	      System.out.println("enter the number");
	      int base=sc.nextInt();
	      System.out.println("enter the power");
	      int exponent = sc.nextInt();
	      long result = 1;
	      while (exponent != 0) {
	        result *= base;
	        --exponent;
	      }
	      System.out.println("Answer = " + result);
	      
//count number of vowels
	      char chr;
	      int count=0;
	      System.out.println("enter characters");
	      for(int i=0;i<10;i++) {
	      
	      chr=sc.next().charAt(0);
	      if(chr=='a'||chr=='A'||chr=='e'||chr=='E'||chr=='i'||chr=='I'||chr=='o'||chr=='O'||chr=='u'||chr=='U')
	      count++;
	      }
	      System.out.printf("number of vowels is= %d\n",count);    

          
  //ascii value
          System.out.println("Ascii value of a character");
          System.out.println("enter the character");
          int ch1= sc.next().charAt(0);        
          System.out.println("The ASCII value of " + ch1 + " is: " + ch1);  

//swap 2 numbers
          System.out.println("swap 2 numbers");
          System.out.println("enter first number");
          int a=sc.nextInt();
          System.out.println("enter second number");
          int b=sc.nextInt();
          System.out.println("before swap a= "+a+" b is "+b);
          int c;
          c=a;
          a=b;
          b=c;
          System.out.println("after swap a= "+a+" b is "+b);
          
// factorial of number using recursion
          System.out.println("factorial of a nuber using recurssion");
          System.out.println("enter the number");
          int n=sc.nextInt();
          Task t=new Task();
          int fact=t.factorial(n);
          System.out.println("Factorial of "+n+" is: "+fact); 
	}
	
	int factorial(int num){    
		  if (num == 0)    
		    return 1;    
		  else    
		    return(num * factorial(num-1));    
		 }

}


//patternpackage demo;

public class Pattern {
	public static void main(String args[]) {
		
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(j);
			}
			System.out.println("");
		}
		System.out.println("\n");
		
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(i);
			}
			System.out.println("");
		}
		System.out.println("\n");
	
		int n = 5;       
		for (int i=0; i<n; i++)   
		{  
			for (int j=2*(n-i); j>=0; j--)         
			{  
				System.out.print(" ");   
			}   
			for (int j=0; j<=i; j++ )   
			{   
				System.out.print("* ");   
			}   
			System.out.println();   
		}   
	
	
	}
	
}
//count chracter in string
package demo;
import java.util.*;

public class Task {
	public static void main(String arg[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the striing");
		String str = sc.next();
		System.out.println("enter the character to count the occurrence");
		char ch=sc.next().charAt(0);           
		int count=0;
		for(int i=0; i<str.length(); i++)
		{
		      if(str.charAt(i) == ch)
		      count++;
		 }
		  
		  System.out.println("The occurrence of "+ch+" in the string is  "+count+" times");   
		 }

}
//ascii value of ato z

public class Task {
	public static void main(String arg[]) {
	char ch ='A';
	System.out.println("ascii value from A to Z is");
		for(int i='A';i<='Z';i++) {
			System.out.println(ch+":"+i);
			ch++;
		}
		 }

}

----------------------------------------------------------------------------------
---------------------------------------7/12-----------------------------------------

public class Task {
	public static void main(String arg[]) {
		for(int i=1;i<=10;i++) {
			try {
			if(i==5) {
				
				i=i/0;
				}
			System.out.println(i);
			}
			catch(Exception e) {
				System.out.println(e);
			}
			
		}
		 try {
			    String var=null;

			    System.out.print(var.charAt(3));
			    }

			    catch(Exception e)
			    {
			        System.out.print(e);
			    }
	}

}

------
package demo;
import java.util.*;

public class Task {
	public static void main(String arg[]) {
//arithmatic expression
        try {
            int a = 30, b = 0;
            int c = a/b;  
            System.out.println ("Result = " + c);
        }
        catch(ArithmeticException e) {
            System.out.println ("Can't divide a number by 0 " +e);
        }
        System.out.println("\n");
 //null pointer
        try {
            String a = null;
            System.out.println(a.charAt(0));
        } 
        catch(NullPointerException ex) {
            System.out.println("NullPointerException  "+ex);
        }
        System.out.println("\n");
//arrayindexoutofbound
        
        try{
            int a[] = new int[5];
            a[6] = 9; 
        }
        catch(ArrayIndexOutOfBoundsException exp){
            System.out.println ("Array Index is Out Of Bounds "+exp);
        }
        
        
	}

}
//exception handling
package demo;

public class demo {
	public static void main(String args[]) {
		int i=5;
		try {
			if(i==5) {
				
				i=i/0;
				}
			System.out.println(i);
			}
		catch(ArithmeticException e) {
	            System.out.println ("Can't divide a number by 0 " +e);
	    }
		catch(NullPointerException ex) {
	            System.out.println("NullPointerException  "+ex);
	    }
		catch(ArrayIndexOutOfBoundsException exp){
	            System.out.println ("Array Index is Out Of Bounds "+exp);
	        }
	
	}
}
-----
package demo;
import java.util.*;

public class demo {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the marks");
        int marks = sc.nextInt();
        try{
         if(marks<200)
         {
             throw new StudentFailed("marks less than 200 failed exception");
         }
         else {
        	 System.out.println("student marks is: "+marks);
         }
        }
        catch(StudentFailed e)
        {
               System.out.println(e); 
        }
        System.out.println("\n");
        
        System.out.println("enter the number");
        int num = sc.nextInt();
        try{
         if(num<0)
         {
             throw new NegativeNumber("number is less than 0, negative exception");
         }
         else {
        	 System.out.println("number is: "+num);
         }
        }
        catch(NegativeNumber ex)
        {
               System.out.println(ex); 
        }
        System.out.println("\n");
        
        System.out.println("enter the string");
        String str = sc.next();
        try{
         if(str.length()<10)
         {
             throw new PasswordgLengthNotMatch("string length is less than 10, password lentgh not grater than 10 exception");
         }
         else {
        	 System.out.println("string is: "+str);
         }
        }
        catch(PasswordgLengthNotMatch ex)
        {
               System.out.println(ex); 
        }
        System.out.println("\n");
        
        System.out.println("enter the number");
        int num1 = sc.nextInt();
        try{
         if(num1%2!=0)
         {
             throw new NotEven("number is not divisible by 2, not even exception");
         }
         else {
        	 System.out.println("number is: "+num1);
         }
        }
        catch(NotEven ex)
        {
               System.out.println(ex); 
        }
    }
}
 

class StudentFailed extends Exception
{
 
    public StudentFailed (String message) {
        super(message);

    }
   
}
class NegativeNumber extends Exception
{
 
    public NegativeNumber (String message) {
    super(message);

    }
    
}
class PasswordgLengthNotMatch extends Exception
{
 
    public PasswordgLengthNotMatch (String message) {
    super(message);

    }
    
}
class NotEven extends Exception
{
 
    public NotEven (String message) {
    super(message);

    }
    
}